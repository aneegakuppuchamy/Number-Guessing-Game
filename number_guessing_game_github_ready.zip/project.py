import random
import json
import os
from datetime import datetime

class NumberGuessingGame:
    def __init__(self):
        self.users_file = "users.json"
        self.users = self.load_users()
        self.current_user = None
        self.game_active = False
        self.secret_number = None
        self.chances_left = 5
        self.current_score = 0
        self.level = 1
        
    def load_users(self):
        """Load user data from JSON file"""
        if os.path.exists(self.users_file):
            with open(self.users_file, 'r') as f:
                return json.load(f)
        return {}
    
    def save_users(self):
        """Save user data to JSON file"""
        with open(self.users_file, 'w') as f:
            json.dump(self.users, f, indent=4)
    
    def login_page(self):
        """Display login/signup page"""
        print("\n" + "="*50)
        print("      NUMBER GUESSING GAME - LOGIN PAGE")
        print("="*50)
        
        while True:
            print("\n1. Login")
            print("2. Sign Up")
            print("3. Exit")
            
            choice = input("\nEnter your choice (1-3): ").strip()
            
            if choice == '1':
                self.login()
            elif choice == '2':
                self.signup()
            elif choice == '3':
                print("\nThank you for playing! Goodbye!")
                exit()
            else:
                print("Invalid choice! Please try again.")
    
    def signup(self):
        """Create a new user account"""
        print("\n" + "-"*50)
        print("SIGN UP")
        print("-"*50)
        
        username = input("Enter username: ").strip()
        
        if username in self.users:
            print("Username already exists! Please try a different username.")
            return
        
        if len(username) < 3:
            print("Username must be at least 3 characters long!")
            return
        
        password = input("Enter password: ").strip()
        
        if len(password) < 4:
            print("Password must be at least 4 characters long!")
            return
        
        self.users[username] = {
            "password": password,
            "total_score": 0,
            "games_played": 0,
            "best_score": 0,
            "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        
        self.save_users()
        print(f"\nAccount created successfully! Welcome {username}!")
        self.current_user = username
        self.main_menu()
    
    def login(self):
        """Login to existing account"""
        print("\n" + "-"*50)
        print("LOGIN")
        print("-"*50)
        
        username = input("Enter username: ").strip()
        password = input("Enter password: ").strip()
        
        if username not in self.users:
            print("Username not found! Please sign up first.")
            return
        
        if self.users[username]["password"] != password:
            print("Incorrect password! Please try again.")
            return
        
        print(f"\nLogin successful! Welcome back, {username}!")
        self.current_user = username
        self.main_menu()
    
    def main_menu(self):
        """Main menu after login"""
        while True:
            print("\n" + "="*50)
            print(f"      WELCOME {self.current_user.upper()}")
            print("="*50)
            print(f"Total Score: {self.users[self.current_user]['total_score']}")
            print(f"Best Score: {self.users[self.current_user]['best_score']}")
            print(f"Games Played: {self.users[self.current_user]['games_played']}")
            
            print("\n1. Play Game")
            print("2. View Statistics")
            print("3. Logout")
            
            choice = input("\nEnter your choice (1-3): ").strip()
            
            if choice == '1':
                self.select_level()
            elif choice == '2':
                self.view_statistics()
            elif choice == '3':
                print(f"\nLogging out... Goodbye {self.current_user}!")
                self.current_user = None
                self.login_page()
            else:
                print("Invalid choice! Please try again.")
    
    def select_level(self):
        """Select game difficulty level"""
        print("\n" + "-"*50)
        print("SELECT LEVEL")
        print("-"*50)
        
        print("\n1. Easy (Range: 1-50)")
        print("2. Medium (Range: 1-100)")
        print("3. Hard (Range: 1-200)")
        
        choice = input("\nEnter your choice (1-3): ").strip()
        
        if choice == '1':
            self.level = 1
            max_range = 50
            print(f"\nYou selected Easy level! Range: 1-{max_range}")
        elif choice == '2':
            self.level = 2
            max_range = 100
            print(f"\nYou selected Medium level! Range: 1-{max_range}")
        elif choice == '3':
            self.level = 3
            max_range = 200
            print(f"\nYou selected Hard level! Range: 1-{max_range}")
        else:
            print("Invalid choice!")
            return
        
        self.play_game(max_range)
    
    def play_game(self, max_range):
        """Start the number guessing game"""
        self.secret_number = random.randint(1, max_range)
        self.chances_left = 5
        self.current_score = 0
        self.game_active = True
        
        print("\n" + "="*50)
        print(f"      LEVEL {self.level} - GAME STARTED!")
        print("="*50)
        print(f"I'm thinking of a number between 1 and {max_range}")
        print(f"You have {self.chances_left} chances to guess it!")
        
        while self.game_active and self.chances_left > 0:
            try:
                guess = int(input(f"\nEnter your guess (Chances left: {self.chances_left}): "))
                
                if guess < 1 or guess > max_range:
                    print(f"Please enter a number between 1 and {max_range}!")
                    continue
                
                self.check_guess(guess)
                
            except ValueError:
                print("Invalid input! Please enter a valid number.")
        
        if self.game_active:
            self.end_game(max_range)
    
    def check_guess(self, guess):
        """Check the user's guess"""
        if guess == self.secret_number:
            self.current_score = self.chances_left * 10 * self.level
            print(f"\n🎉 Correct! The number was {self.secret_number}!")
            print(f"You scored: {self.current_score} points!")
            self.game_active = False
            self.update_score(self.current_score, True)
        elif guess < self.secret_number:
            self.chances_left -= 1
            print(f"❌ Too low! Try again. Chances left: {self.chances_left}")
        else:
            self.chances_left -= 1
            print(f"❌ Too high! Try again. Chances left: {self.chances_left}")
        
        if self.chances_left == 0 and self.game_active:
            self.game_active = False
    
    def end_game(self, max_range):
        """Handle game over"""
        print("\n" + "="*50)
        print("      GAME OVER")
        print("="*50)
        print(f"The secret number was: {self.secret_number}")
        print(f"Better luck next time!")
        self.update_score(0, False)
        
        play_again = input("\nDo you want to play again? (yes/no): ").strip().lower()
        if play_again in ['yes', 'y']:
            self.select_level()
    
    def update_score(self, score, won):
        """Update user score and statistics"""
        user = self.users[self.current_user]
        user['total_score'] += score
        user['games_played'] += 1
        
        if score > user['best_score']:
            user['best_score'] = score
        
        self.save_users()
        
        if won:
            print(f"\n✅ Score added to your account!")
        else:
            print(f"\n❌ No points earned this round.")
    
    def view_statistics(self):
        """Display user statistics"""
        user = self.users[self.current_user]
        
        print("\n" + "="*50)
        print("      YOUR STATISTICS")
        print("="*50)
        print(f"Username: {self.current_user}")
        print(f"Total Score: {user['total_score']} points")
        print(f"Games Played: {user['games_played']}")
        print(f"Best Score: {user['best_score']} points")
        print(f"Account Created: {user['created_at']}")
        
        if user['games_played'] > 0:
            avg_score = user['total_score'] / user['games_played']
            print(f"Average Score: {avg_score:.2f} points")
        
        print("="*50)
    
    def start(self):
        """Start the application"""
        self.login_page()

# Main execution
if __name__ == "__main__":
    game = NumberGuessingGame()
    game.start()
