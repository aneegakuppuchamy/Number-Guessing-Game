# Number Guessing Game 🎯

A beginner-friendly command-line Number Guessing Game built with Python. Players can create an account, log in, choose a difficulty level, play rounds, and view their scores and statistics.

## Features
- User sign-up and login
- Three difficulty levels: Easy (1–50), Medium (1–100), and Hard (1–200)
- Five guesses per round
- Score calculation based on remaining chances and difficulty
- Saves user scores and statistics in a local `users.json` file
- Displays total score, best score, games played, and average score

## Requirements
- Python 3.8 or newer
- No third-party packages required

## How to Run
1. Install Python from the official Python website if it is not already installed.
2. Download or clone this repository.
3. Open a terminal/Command Prompt in the project folder.
4. Run:

   ```bash
   python project.py
   ```

   On some Windows installations, use:

   ```bash
   py project.py
   ```

## How to Play
1. Choose **Sign Up** to create an account, or **Login** if you already have one.
2. Choose **Play Game**.
3. Select Easy, Medium, or Hard.
4. Guess the secret number within five attempts.
5. Choose **View Statistics** to see your progress.

## Data Storage
The game creates a local `users.json` file to store account and score data. This file is generated when the program runs and is intentionally excluded from Git tracking.

> **Security note:** This is an educational console project. Passwords are stored as plain text in the local JSON file, so do not use real or reused passwords. For a real application, use secure password hashing and a proper authentication system.

## Project Structure
```text
number_guessing_game_github/
├── project.py
├── README.md
├── .gitignore
├── LICENSE
└── Number_Guessing_Game_Project_Documentation.pdf
```

## License
This project is provided under the MIT License. See `LICENSE`.
